﻿TermLink offline Bluetooth chat
================================

Requirements:
- Windows 10 or Windows 11
- Bluetooth Low Energy enabled
- A BLE adapter supporting central and peripheral roles
- Another nearby computer running TermLink

Start normal chat:
  .\TermLink.exe --chat

Inside TermLink:
  /nearby
  /pair 1
  /verify CODE
  /name CODE Friend
  Type a message and press Enter
  /quit

The two users must compare the complete verification code through a trusted
independent method before entering /verify. Chat sessions, keys, peer names,
and message text are held only in memory and disappear when TermLink exits.
Terminal scrollback, screenshots, and operating-system paging are outside
TermLink's control.

This is an unsigned experimental executable. Windows may display a security
warning. The Microsoft C runtime is statically linked for portability. Verify
the SHA-256 checksum before sharing or running the file.
